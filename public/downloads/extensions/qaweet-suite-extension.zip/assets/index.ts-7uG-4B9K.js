import{i as e,n as t,r as n,t as r}from"./jsx-runtime-D2WGZPft.js";import{n as i}from"./formFiller-SucdqjOs.js";var a=t(),o=e(n(),1),s=r(),c=({state:e})=>{if(!e.isVisible||!e.imageUrl)return null;let t=Math.max(0,Math.min(100,e.opacity))/100;return(0,s.jsx)(`div`,{id:`qa-pixel-overlay-container`,style:{position:`fixed`,top:0,left:0,width:`100vw`,height:`100vh`,pointerEvents:`none`,zIndex:2147483647,overflow:`hidden`},children:(0,s.jsxs)(`div`,{id:`qa-pixel-overlay-image-wrapper`,style:{position:`absolute`,top:`${e.y}px`,left:`${e.x}px`,opacity:t,pointerEvents:e.isLocked?`none`:`auto`,userSelect:`none`,border:e.isLocked?`none`:`2px dashed #6366f1`,boxSizing:`border-box`,transition:`opacity 0.1s ease, border 0.15s ease`},children:[(0,s.jsx)(`img`,{src:e.imageUrl,alt:`QA Mockup Overlay`,style:{display:`block`,maxWidth:`none`,maxHeight:`none`,pointerEvents:`none`}}),!e.isLocked&&(0,s.jsxs)(`div`,{style:{position:`absolute`,top:`-24px`,left:0,backgroundColor:`#6366f1`,color:`#ffffff`,fontSize:`11px`,fontWeight:600,padding:`2px 6px`,borderRadius:`3px`,fontFamily:`monospace`,pointerEvents:`none`,whiteSpace:`nowrap`},children:[`Overlay (`,e.x,`px, `,e.y,`px) - Unlocked`]})]})})},l=!1,u=null,d=null,f=null;function p(e){typeof document>`u`||(l=e,l?(m(),document.addEventListener(`mouseover`,b,!0),document.addEventListener(`click`,x,!0),document.addEventListener(`keydown`,g,!0)):(h(),document.removeEventListener(`mouseover`,b,!0),document.removeEventListener(`click`,x,!0),document.removeEventListener(`keydown`,g,!0)))}function m(){if(typeof document>`u`)return;let e=document.body||document.documentElement;e&&(u||(u=document.createElement(`div`),u.id=`qa-element-inspector-overlay`,u.style.position=`fixed`,u.style.pointerEvents=`none`,u.style.zIndex=`2147483646`,u.style.border=`2px solid #6366f1`,u.style.backgroundColor=`rgba(99, 102, 241, 0.15)`,u.style.boxShadow=`0 0 0 1px rgba(255, 255, 255, 0.4)`,u.style.transition=`all 0.05s ease-out`,e.appendChild(u)),d||(d=document.createElement(`div`),d.id=`qa-element-inspector-tooltip`,d.style.position=`fixed`,d.style.pointerEvents=`none`,d.style.zIndex=`2147483647`,d.style.backgroundColor=`#0f172a`,d.style.color=`#f8fafc`,d.style.border=`1px solid #475569`,d.style.borderRadius=`8px`,d.style.padding=`10px 14px`,d.style.fontFamily=`monospace`,d.style.fontSize=`11px`,d.style.boxShadow=`0 10px 25px -5px rgba(0,0,0,0.6)`,d.style.maxWidth=`360px`,e.appendChild(d)))}function h(){u&&=(u.remove(),null),d&&=(d.remove(),null),f=null}function g(e){e.key===`Escape`&&l&&(p(!1),typeof chrome<`u`&&chrome.runtime&&chrome.runtime.sendMessage({type:`INSPECTOR_STATE_CHANGE`,payload:{enabled:!1}}).catch(()=>{}))}function _(e){if(e.id)return`#${e.id}`;let t=[],n=e;for(;n&&n.nodeType===Node.ELEMENT_NODE&&n!==document.body;){let e=n.tagName.toLowerCase();if(n.className&&typeof n.className==`string`){let t=n.className.trim().split(/\s+/).filter(e=>e&&!e.startsWith(`qa-`)).slice(0,2);t.length>0&&(e+=`.${t.join(`.`)}`)}if(t.unshift(e),n=n.parentElement,t.length>=3)break}return t.join(` > `)||e.tagName.toLowerCase()}function v(e){let t=e.tagName.toLowerCase(),n=e.getAttribute(`type`),r=e.getAttribute(`role`);return t===`input`&&n?`input[type="${n}"]`:t===`button`?n?`button[type="${n}"]`:`button`:r?`${t}[role="${r}"]`:t}function y(e){return e?e.split(`,`)[0].replace(/['"]/g,``).trim():`sans-serif`}function b(e){if(typeof document>`u`||typeof window>`u`||!l||!u||!d)return;let t=e.target;if(!t||t===u||t===d||t.closest(`qa-ext-shadow-host`))return;f=t;let n=t.getBoundingClientRect(),r=window.getComputedStyle(t);u.style.top=`${n.top}px`,u.style.left=`${n.left}px`,u.style.width=`${n.width}px`,u.style.height=`${n.height}px`;let i=S(r.color),a=S(r.backgroundColor),o=_(t),s=v(t),c=y(r.fontFamily),p=Math.min(e.clientX+15,window.innerWidth-370),m=Math.min(e.clientY+15,window.innerHeight-220);d.style.top=`${m}px`,d.style.left=`${p}px`,d.innerHTML=`
    <div style="font-weight: 700; color: #818cf8; margin-bottom: 2px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${o}</div>
    <div style="font-size: 10px; color: #a5b4fc; margin-bottom: 6px;">Type: <strong style="color:#e0e7ff;">&lt;${s}&gt;</strong></div>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 4px; color: #cbd5e1; font-size: 10.5px;">
      <div>Dimensions: <span style="color:#e2e8f0;font-weight:600;">${Math.round(n.width)} × ${Math.round(n.height)}px</span></div>
      <div>Font: <span style="color:#e2e8f0;font-weight:600;">${c}</span></div>
      <div>Size: <span style="color:#e2e8f0;font-weight:600;">${r.fontSize}</span></div>
      <div>Weight: <span style="color:#e2e8f0;font-weight:600;">${r.fontWeight}</span></div>
      <div>Line Ht: <span style="color:#e2e8f0;font-weight:600;">${r.lineHeight}</span></div>
      <div>Letter Spacing: <span style="color:#e2e8f0;font-weight:600;">${r.letterSpacing}</span></div>
      <div>Color: <span style="color:#38bdf8;font-weight:600;">${i}</span></div>
      <div>Bg Color: <span style="color:#f472b6;font-weight:600;">${a}</span></div>
    </div>
    <div style="font-size: 9px; color: #94a3b8; margin-top: 6px; border-top: 1px solid #334155; padding-top: 4px;">
      Click element to copy design tokens | Press ESC to exit
    </div>
  `}function x(e){if(typeof window>`u`||!l||!f)return;e.preventDefault(),e.stopPropagation();let t=window.getComputedStyle(f),n=f.getBoundingClientRect(),r=_(f),i=v(f),a=y(t.fontFamily),o={selector:r,tag:f.tagName.toLowerCase(),elementType:i,fontFamily:a,fontSize:t.fontSize,fontWeight:t.fontWeight,fontStyle:t.fontStyle,lineHeight:t.lineHeight,letterSpacing:t.letterSpacing,color:S(t.color),backgroundColor:S(t.backgroundColor),padding:t.padding,margin:t.margin,dimensions:`${Math.round(n.width)} × ${Math.round(n.height)}px`,width:Math.round(n.width),height:Math.round(n.height),timestamp:Date.now()};navigator.clipboard.writeText(JSON.stringify(o,null,2)),d&&(d.innerHTML=`
      <div style="color: #34d399; font-weight:700; text-align: center; padding: 6px 0;">
        ✓ Design tokens copied to clipboard!
      </div>
    `),typeof chrome<`u`&&chrome.runtime&&chrome.runtime.sendMessage&&chrome.runtime.sendMessage({type:`INSPECTED_ELEMENT_UPDATE`,payload:o}).catch(()=>{})}function S(e){let t=e.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)/);if(!t)return e;let n=e=>parseInt(e,10).toString(16).padStart(2,`0`);return`#${n(t[1])}${n(t[2])}${n(t[3])}`.toUpperCase()}var C={lcp:null,cls:0,inp:null,ttfb:null};function w(){if(!(typeof window>`u`||typeof document>`u`||typeof PerformanceObserver>`u`)){try{let e=performance.getEntriesByType(`navigation`)[0];e&&(C.ttfb=Math.round(e.responseStart))}catch{}try{new PerformanceObserver(e=>{let t=e.getEntries(),n=t[t.length-1];n&&(C.lcp=Math.round(n.startTime),T())}).observe({type:`largest-contentful-paint`,buffered:!0})}catch{}try{let e=0;new PerformanceObserver(t=>{for(let n of t.getEntries())n.hadRecentInput||(e+=n.value);C.cls=Number(e.toFixed(3)),T()}).observe({type:`layout-shift`,buffered:!0})}catch{}try{new PerformanceObserver(e=>{for(let t of e.getEntries()){let e=Math.round(t.duration);(C.inp===null||e>C.inp)&&(C.inp=e,T())}}).observe({type:`first-input`,buffered:!0})}catch{}T()}}function T(){typeof chrome<`u`&&chrome.runtime&&chrome.runtime.sendMessage&&chrome.runtime.sendMessage({type:`VITALS_UPDATE`,payload:C}).catch(()=>{})}var E=!1,D=0,O=[];function k(e){typeof document>`u`||(E=e,E?(document.addEventListener(`click`,j,!0),document.addEventListener(`change`,M,!0)):(document.removeEventListener(`click`,j,!0),document.removeEventListener(`change`,M,!0)))}function A(){O=[],D=0}function j(e){if(typeof document>`u`||!E)return;let t=e.target;if(!t||t.closest(`qa-ext-shadow-host`)||t.closest(`#qa-element-inspector-overlay`))return;let n=N(t),r=t.innerText?.trim().slice(0,30)||t.getAttribute(`title`)||t.getAttribute(`aria-label`)||``;D++;let i={id:`step_${Date.now()}_${D}`,stepNumber:D,timestamp:Date.now(),action:`click`,description:`Clicked ${t.tagName.toLowerCase()}${n?` (${n})`:``}${r?` "${r}"`:``}`,targetSelector:n};O.push(i),P()}function M(e){if(typeof document>`u`||!E)return;let t=e.target;if(!(!t||t.closest(`qa-ext-shadow-host`))&&(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement)){let e=N(t),n=t instanceof HTMLInputElement&&t.type===`password`?`••••••••`:t.value.slice(0,50);D++;let r={id:`step_${Date.now()}_${D}`,stepNumber:D,timestamp:Date.now(),action:`input`,description:`Entered value in ${t.tagName.toLowerCase()}${e?` (${e})`:``}`,value:n,targetSelector:e};O.push(r),P()}}function N(e){if(e.id)return`#${e.id}`;if(e.getAttribute(`name`))return`[name="${e.getAttribute(`name`)}"]`;let t=e.className&&typeof e.className==`string`?e.className.trim().split(/\s+/)[0]:``;return t?`.${t}`:e.tagName.toLowerCase()}function P(){typeof chrome<`u`&&chrome.runtime&&chrome.runtime.sendMessage&&chrome.runtime.sendMessage({type:`STEPS_UPDATE`,payload:O}).catch(()=>{})}var F=null,I=[];function L(){F&&F.parentNode&&F.parentNode.removeChild(F),F=null}function R(e,t){L();let n=document.createElement(`div`);n.id=`qa-region-selector-host`,n.style.position=`fixed`,n.style.top=`0`,n.style.left=`0`,n.style.width=`100vw`,n.style.height=`100vh`,n.style.zIndex=`2147483647`,n.style.cursor=`crosshair`,n.style.userSelect=`none`;let r=n.attachShadow({mode:`open`}),i=document.createElement(`style`);i.textContent=`
    .backdrop {
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background: rgba(15, 23, 42, 0.35);
      backdrop-filter: blur(1px);
    }
    .selection-box {
      position: absolute;
      border: 2px dashed #6366f1;
      background: rgba(99, 102, 241, 0.15);
      box-shadow: 0 0 0 9999px rgba(15, 23, 42, 0.45);
      pointer-events: none;
      border-radius: 4px;
    }
    .badge {
      position: absolute;
      bottom: -24px; right: 0;
      background: #1e293b;
      color: #38bdf8;
      font-family: monospace;
      font-size: 11px;
      padding: 2px 6px;
      border-radius: 4px;
      white-space: nowrap;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    }
    .instruction-bar {
      position: absolute;
      top: 16px;
      left: 50%;
      transform: translateX(-50%);
      background: #0f172a;
      color: #f8fafc;
      padding: 8px 16px;
      border-radius: 9999px;
      font-family: system-ui, sans-serif;
      font-size: 12px;
      font-weight: 600;
      border: 1px solid #334155;
      box-shadow: 0 4px 12px rgba(0,0,0,0.4);
      pointer-events: none;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .kbd {
      background: #334155;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 10px;
    }
  `;let a=document.createElement(`div`);a.className=`backdrop`;let o=document.createElement(`div`);o.className=`instruction-bar`,o.innerHTML=`<span>📸 Drag mouse to crop region</span> <span class="kbd">ESC to cancel</span>`,a.appendChild(o);let s=document.createElement(`div`);s.className=`selection-box`,s.style.display=`none`;let c=document.createElement(`div`);c.className=`badge`,s.appendChild(c),a.appendChild(s),r.appendChild(i),r.appendChild(a);let l=!1,u=0,d=0,f=e=>{l=!0,u=e.clientX,d=e.clientY,s.style.left=`${u}px`,s.style.top=`${d}px`,s.style.width=`0px`,s.style.height=`0px`,s.style.display=`block`},p=e=>{if(!l)return;let t=e.clientX,n=e.clientY,r=Math.min(u,t),i=Math.min(d,n),a=Math.abs(t-u),o=Math.abs(n-d);s.style.left=`${r}px`,s.style.top=`${i}px`,s.style.width=`${a}px`,s.style.height=`${o}px`,c.textContent=`${Math.round(a)} × ${Math.round(o)} px`},m=n=>{if(!l)return;l=!1;let r=n.clientX,i=n.clientY,a=Math.min(u,r),o=Math.min(d,i),s=Math.abs(r-u),c=Math.abs(i-d);g(),s>10&&c>10?e({x:a,y:o,width:s,height:c,devicePixelRatio:window.devicePixelRatio||1,scrollX:window.scrollX,scrollY:window.scrollY}):t()},h=e=>{e.key===`Escape`&&(g(),t())},g=()=>{window.removeEventListener(`keydown`,h,!0),L()};a.addEventListener(`mousedown`,f),a.addEventListener(`mousemove`,p),a.addEventListener(`mouseup`,m),window.addEventListener(`keydown`,h,!0),document.body.appendChild(n),F=n}function z(e,t){L();let n=document.createElement(`div`);n.id=`qa-node-selector-host`,n.style.position=`fixed`,n.style.top=`0`,n.style.left=`0`,n.style.width=`100vw`,n.style.height=`100vh`,n.style.zIndex=`2147483647`,n.style.pointerEvents=`none`;let r=n.attachShadow({mode:`open`}),i=document.createElement(`style`);i.textContent=`
    .highlight-box {
      position: fixed;
      border: 2px solid #3b82f6;
      background: rgba(59, 130, 246, 0.15);
      pointer-events: none;
      transition: all 0.05s ease-out;
      border-radius: 4px;
      z-index: 2147483647;
    }
    .badge {
      position: absolute;
      top: -24px;
      left: 0;
      background: #1e293b;
      color: #60a5fa;
      font-family: monospace;
      font-size: 11px;
      font-weight: 600;
      padding: 2px 6px;
      border-radius: 4px;
      white-space: nowrap;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    }
    .instruction-bar {
      position: fixed;
      top: 16px;
      left: 50%;
      transform: translateX(-50%);
      background: #0f172a;
      color: #f8fafc;
      padding: 8px 16px;
      border-radius: 9999px;
      font-family: system-ui, sans-serif;
      font-size: 12px;
      font-weight: 600;
      border: 1px solid #334155;
      box-shadow: 0 4px 12px rgba(0,0,0,0.4);
      pointer-events: auto;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .kbd {
      background: #334155;
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 10px;
    }
  `;let a=document.createElement(`div`);a.className=`highlight-box`,a.style.display=`none`;let o=document.createElement(`div`);o.className=`badge`,a.appendChild(o);let s=document.createElement(`div`);s.className=`instruction-bar`,s.innerHTML=`<span>🎯 Hover element & click to capture node</span> <span class="kbd">ESC to cancel</span>`,r.appendChild(i),r.appendChild(a),r.appendChild(s);let c=null,l=e=>{n.style.pointerEvents=`none`;let t=document.elementFromPoint(e.clientX,e.clientY);if(!t||t===n||n.contains(t))return;c=t;let r=t.getBoundingClientRect();a.style.left=`${r.left}px`,a.style.top=`${r.top}px`,a.style.width=`${r.width}px`,a.style.height=`${r.height}px`,a.style.display=`block`;let i=t.tagName.toLowerCase(),s=t.id?`#${t.id}`:``,l=t.className&&typeof t.className==`string`?`.${t.className.split(` `)[0]}`:``;o.textContent=`${i}${s}${l} (${Math.round(r.width)}×${Math.round(r.height)}px)`},u=n=>{if(n.preventDefault(),n.stopPropagation(),!c){f(),t();return}let r=c.getBoundingClientRect();f(),e({x:r.left,y:r.top,width:r.width,height:r.height,devicePixelRatio:window.devicePixelRatio||1,scrollX:window.scrollX,scrollY:window.scrollY})},d=e=>{e.key===`Escape`&&(f(),t())},f=()=>{document.removeEventListener(`mousemove`,l,!0),document.removeEventListener(`click`,u,!0),window.removeEventListener(`keydown`,d,!0),L()};document.addEventListener(`mousemove`,l,!0),document.addEventListener(`click`,u,!0),window.addEventListener(`keydown`,d,!0),document.body.appendChild(n),F=n}function B(){I.length>0||document.querySelectorAll(`*`).forEach(e=>{if(!(e instanceof HTMLElement)||e.id?.startsWith(`qa-`))return;let t=window.getComputedStyle(e);(t.position===`fixed`||t.position===`sticky`)&&(I.push({element:e,originalVisibility:e.style.visibility,originalOpacity:e.style.opacity}),e.style.visibility=`hidden`)})}function V(){I.forEach(({element:e,originalVisibility:t,originalOpacity:n})=>{e.style.visibility=t,e.style.opacity=n}),I=[]}var H=null,U=null,W=null,G=null;typeof document<`u`&&typeof window<`u`&&(w(),document.addEventListener(`contextmenu`,e=>{G=e.target},!0),document.addEventListener(`focusin`,e=>{G=e.target},!0),typeof chrome<`u`&&chrome.storage&&chrome.storage.local&&(chrome.storage.local.get([`pixelOverlayState`],e=>{e.pixelOverlayState&&q(e.pixelOverlayState)}),chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&e.pixelOverlayState&&q(e.pixelOverlayState.newValue)})),window.addEventListener(`error`,e=>{$({id:`err_${Date.now()}_${Math.random().toString(36).substr(2,5)}`,timestamp:Date.now(),type:`error`,message:e.message||`Script Error`,source:e.filename,lineno:e.lineno,colno:e.colno,stack:e.error?.stack,url:window.location.href})}),window.addEventListener(`unhandledrejection`,e=>{let t=e.reason,n=typeof t==`string`?t:t?.message||`Unhandled Promise Rejection`;$({id:`rej_${Date.now()}_${Math.random().toString(36).substr(2,5)}`,timestamp:Date.now(),type:`unhandledrejection`,message:n,stack:t?.stack,url:window.location.href})}));function K(){if(typeof document>`u`)return null;if(!H){H=document.createElement(`qa-ext-shadow-host`),H.style.position=`absolute`,H.style.top=`0`,H.style.left=`0`,H.style.width=`0`,H.style.height=`0`,H.style.zIndex=`2147483647`,H.style.pointerEvents=`none`,U=H.attachShadow({mode:`open`});let e=document.body||document.documentElement;e&&e.appendChild(H);let t=document.createElement(`div`);t.id=`qa-shadow-root`,U.appendChild(t),W=(0,a.createRoot)(t)}return U}function q(e){typeof document>`u`||(K(),W&&W.render(o.createElement(c,{state:e})))}typeof chrome<`u`&&chrome.runtime&&chrome.runtime.onMessage&&chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type===`UPDATE_OVERLAY`&&(q(e.payload),n({success:!0})),e.type===`INJECT_PAYLOAD`&&(Q(e.payload?.value||``),n({success:!0})),e.type===`TOGGLE_INSPECTOR`&&(p(!!e.payload?.enabled),n({success:!0})),e.type===`TOGGLE_RECORDER`&&(e.payload?.clear&&A(),k(!!e.payload?.enabled),n({success:!0})),e.type===`FILL_SMART_FORM`&&(ee(e.payload?.data||{}),n({success:!0})),e.type===`INJECT_FILE`&&(te(e.payload),n({success:!0})),e.type===`RESIZE_VIEWPORT`&&(Z(e.payload),n({success:!0})),e.type===`EXTRACT_PROJECT_THEME`&&n({success:!0,theme:Y()}),e.type===`EXTRACT_PAGE_VISUAL_SUMMARY`&&n({success:!0,summary:J()}),e.type===`START_REGION_SELECTION`&&(R(e=>{chrome.runtime.sendMessage({type:`REGION_SELECTED`,payload:e})},()=>{chrome.runtime.sendMessage({type:`SELECTION_CANCELLED`})}),n({success:!0})),e.type===`START_NODE_SELECTION`&&(z(e=>{chrome.runtime.sendMessage({type:`NODE_SELECTED`,payload:e})},()=>{chrome.runtime.sendMessage({type:`SELECTION_CANCELLED`})}),n({success:!0})),e.type===`GET_FULL_PAGE_METRICS`){let e=document.documentElement,t=document.body;return n({success:!0,metrics:{totalWidth:Math.max(e.scrollWidth,t.scrollWidth,e.clientWidth),totalHeight:Math.max(e.scrollHeight,t.scrollHeight,e.clientHeight),viewportWidth:window.innerWidth,viewportHeight:window.innerHeight,devicePixelRatio:window.devicePixelRatio||1,scrollX:window.scrollX,scrollY:window.scrollY}}),!0}if(e.type===`PREPARE_PAGE_SLICE`){let{scrollX:t,scrollY:r,hideFixed:i}=e.payload||{};return window.scrollTo(t||0,r||0),i&&B(),n({success:!0}),!0}if(e.type===`RESTORE_PAGE_SLICES`){let{originalScrollX:t,originalScrollY:r}=e.payload||{};return V(),window.scrollTo(t||0,r||0),n({success:!0}),!0}});function J(){if(typeof document>`u`||typeof window>`u`)return{id:`summary-${Date.now()}`,url:``,title:``,domain:``,textColors:[],bgColors:[],typography:[],borderRadii:[],borderStyles:[],boxShadows:[],scannedElementsCount:0,extractedAt:Date.now()};let e=window.location.href,t=document.title||e,n=window.location.hostname||`localhost`,r=new Map,i=new Map,a=new Map,o=new Map,s=new Map,c=new Map,l=Array.from(document.querySelectorAll(`body *`)).slice(0,1e3);l.forEach(e=>{let t=window.getComputedStyle(e);if(t.color&&t.color!==`transparent`){let e=X(t.color);r.set(e,(r.get(e)||0)+1)}if(t.backgroundColor&&t.backgroundColor!==`transparent`&&t.backgroundColor!==`rgba(0, 0, 0, 0)`){let e=X(t.backgroundColor);i.set(e,(i.get(e)||0)+1)}if(t.fontFamily){let e=t.fontFamily.split(`,`)[0].replace(/['"]/g,``).trim();if(e){let n=`${t.fontWeight||`400`}___${t.fontSize||`14px`}___${t.lineHeight||`normal`}`;a.has(e)||a.set(e,new Map);let r=a.get(e);r.set(n,(r.get(n)||0)+1)}}if(t.borderRadius&&t.borderRadius!==`0px`){let e=t.borderRadius;o.set(e,(o.get(e)||0)+1)}if(t.borderStyle&&t.borderStyle!==`none`&&t.borderWidth!==`0px`){let e=`${t.borderWidth} ${t.borderStyle} ${X(t.borderColor)}`;s.set(e,(s.get(e)||0)+1)}t.boxShadow&&t.boxShadow!==`none`&&c.set(t.boxShadow,(c.get(t.boxShadow)||0)+1)});let u=Array.from(r.entries()).map(([e,t])=>({hex:e,count:t})).sort((e,t)=>t.count-e.count).slice(0,20),d=Array.from(i.entries()).map(([e,t])=>({hex:e,count:t})).sort((e,t)=>t.count-e.count).slice(0,20),f=Array.from(a.entries()).map(([e,t])=>{let n=0;return{family:e,variants:Array.from(t.entries()).map(([e,t])=>{let[r,i,a]=e.split(`___`);return n+=t,{weight:r,size:i,lineHeight:a,count:t}}).sort((e,t)=>t.count-e.count),totalCount:n}}).sort((e,t)=>t.totalCount-e.totalCount),p=Array.from(o.entries()).map(([e,t])=>({radius:e,count:t})).sort((e,t)=>t.count-e.count).slice(0,10),m=Array.from(s.entries()).map(([e,t])=>({border:e,count:t})).sort((e,t)=>t.count-e.count).slice(0,10),h=Array.from(c.entries()).map(([e,t])=>({shadow:e,count:t})).sort((e,t)=>t.count-e.count).slice(0,10);return{id:`summary-${Date.now()}-${Math.random().toString(36).substring(2,7)}`,url:e,title:t,domain:n,textColors:u,bgColors:d,typography:f,borderRadii:p,borderStyles:m,boxShadows:h,scannedElementsCount:l.length,extractedAt:Date.now()}}function Y(){if(typeof document>`u`||typeof window>`u`)return{colors:[],backgrounds:[],fonts:[],fontSizes:[],extractedAt:Date.now()};let e=new Set,t=new Set,n=new Set,r=new Set;return Array.from(document.querySelectorAll(`body *`)).slice(0,400).forEach(i=>{let a=window.getComputedStyle(i);if(a.color&&a.color!==`transparent`&&e.add(X(a.color)),a.backgroundColor&&a.backgroundColor!==`transparent`&&a.backgroundColor!==`rgba(0, 0, 0, 0)`&&t.add(X(a.backgroundColor)),a.fontFamily){let e=a.fontFamily.split(`,`)[0].replace(/['"]/g,``).trim();e&&n.add(e)}a.fontSize&&r.add(a.fontSize)}),{colors:Array.from(e).slice(0,15),backgrounds:Array.from(t).slice(0,15),fonts:Array.from(n).slice(0,8),fontSizes:Array.from(r).sort((e,t)=>parseFloat(e)-parseFloat(t)).slice(0,10),extractedAt:Date.now()}}function X(e){let t=e.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)/);if(!t)return e;let n=e=>parseInt(e,10).toString(16).padStart(2,`0`);return`#${n(t[1])}${n(t[2])}${n(t[3])}`.toUpperCase()}function Z(e){if(typeof document>`u`)return;let{width:t,height:n,dpr:r=1,zoomLevel:i=1,name:a=`Viewport Frame`,isLandscape:o=!1}=typeof e==`number`?{width:e}:e||{},s=document.getElementById(`qa-viewport-frame-style`),c=document.getElementById(`qa-viewport-badge`);if(t&&t>0){s||(s=document.createElement(`style`),s.id=`qa-viewport-frame-style`,document.head.appendChild(s));let e=i===1?``:`transform: scale(${i}); transform-origin: top center;`,l=n&&n>0?`min-height: ${n}px !important;`:``;s.textContent=`
      html {
        width: ${t}px !important;
        max-width: ${t}px !important;
        ${l}
        margin: 0 auto !important;
        border-left: 3px solid #6366f1 !important;
        border-right: 3px solid #6366f1 !important;
        box-shadow: 0 0 100px rgba(0, 0, 0, 0.85) !important;
        transition: width 0.25s ease, transform 0.25s ease !important;
        position: relative !important;
        ${e}
      }
      body {
        width: 100% !important;
        max-width: 100% !important;
      }
    `;let u=o?`Landscape`:`Portrait`,d=Math.round(i*100),f=`📱 <strong>${a}</strong> | ${t}${n?`×${n}`:``}px | ${r}x DPR | ${d}% | ${u} <span style="margin-left:6px; opacity:0.8;">✕ Reset</span>`;c?c.innerHTML=f:(c=document.createElement(`div`),c.id=`qa-viewport-badge`,c.style.position=`fixed`,c.style.top=`12px`,c.style.right=`12px`,c.style.zIndex=`2147483647`,c.style.backgroundColor=`#4f46e5`,c.style.color=`#ffffff`,c.style.fontFamily=`system-ui, -apple-system, sans-serif`,c.style.fontSize=`11px`,c.style.fontWeight=`500`,c.style.padding=`6px 14px`,c.style.borderRadius=`20px`,c.style.boxShadow=`0 4px 16px rgba(0,0,0,0.5)`,c.style.cursor=`pointer`,c.style.userSelect=`none`,c.style.border=`1px solid rgba(255, 255, 255, 0.2)`,c.innerHTML=f,c.onclick=()=>Z(0),document.body.appendChild(c)),window.dispatchEvent(new Event(`resize`)),window.dispatchEvent(new Event(`orientationchange`));try{typeof chrome<`u`&&chrome.runtime&&chrome.runtime.sendMessage&&chrome.runtime.sendMessage({type:`RESIZE_WINDOW_VIEWPORT`,payload:{width:t,height:n,isLandscape:o}})}catch{}}else s&&s.remove(),c&&c.remove(),window.dispatchEvent(new Event(`resize`))}function Q(e){if(typeof document>`u`)return;let t=document.activeElement||G;if(t)if(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement){let n=Object.getOwnPropertyDescriptor(t instanceof HTMLInputElement?window.HTMLInputElement.prototype:window.HTMLTextAreaElement.prototype,`value`)?.set;n?n.call(t,e):t.value=e,t.dispatchEvent(new Event(`input`,{bubbles:!0})),t.dispatchEvent(new Event(`change`,{bubbles:!0})),t.focus()}else t.isContentEditable&&(t.innerText=e,t.dispatchEvent(new Event(`input`,{bubbles:!0})))}function ee(e){typeof document>`u`||Array.from(document.querySelectorAll(`input:not([type="hidden"]), textarea, select`)).forEach(t=>{if(t.offsetParent===null)return;let n=i(t,e);if(n)if(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement){let e=Object.getOwnPropertyDescriptor(t instanceof HTMLInputElement?window.HTMLInputElement.prototype:window.HTMLTextAreaElement.prototype,`value`)?.set;e?e.call(t,n):t.value=n,t.dispatchEvent(new Event(`input`,{bubbles:!0})),t.dispatchEvent(new Event(`change`,{bubbles:!0}))}else t instanceof HTMLSelectElement&&t.options.length>1&&(t.selectedIndex=1,t.dispatchEvent(new Event(`change`,{bubbles:!0})))})}function te(e){if(typeof document>`u`)return;let t=document.querySelector(`input[type="file"]`);if(!t)return;let n=new Blob([e.content],{type:e.mimeType}),r=new File([n],e.fileName,{type:e.mimeType}),i=new DataTransfer;i.items.add(r),t.files=i.files,t.dispatchEvent(new Event(`change`,{bubbles:!0})),t.dispatchEvent(new Event(`input`,{bubbles:!0}))}function $(e){typeof chrome<`u`&&chrome.runtime&&chrome.runtime.sendMessage&&chrome.runtime.sendMessage({type:`LOG_ERROR`,payload:e}).catch(()=>{})}
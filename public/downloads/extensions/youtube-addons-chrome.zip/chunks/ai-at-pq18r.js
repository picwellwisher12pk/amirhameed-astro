import{c as C,g as x}from"./app-pTXMa8Mv.js";/**
 * @license lucide-react v0.554.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],q=C("chevron-down",N),h={gemini:{label:"Google Gemini",models:["gemini-3.6-flash","gemini-3.6-pro","gemini-3.0-flash","gemini-3.0-pro","gemini-2.5-flash","gemini-2.5-pro","gemini-2.0-flash","gemini-1.5-flash","gemini-1.5-pro"]},openai:{label:"OpenAI",models:["gpt-4o-mini","gpt-4o","gpt-3.5-turbo"]},groq:{label:"Groq (Ultra-Fast)",models:["llama-3.3-70b-versatile","llama-3.1-8b-instant","mixtral-8x7b-32768"]},lmstudio:{label:"LM Studio (Local)",models:["default","qwen2.5-coder-7b-instruct","llama-3.2-3b-instruct","mistral-7b-instruct"],defaultEndpoint:"http://localhost:1234/v1"},ollama:{label:"Ollama (Local)",models:["llama3.2","llama3.1","qwen2.5-coder","mistral","gemma2"],defaultEndpoint:"http://localhost:11434"},custom:{label:"Custom OpenAI-Compatible",models:["deepseek-chat","anthropic/claude-3.5-sonnet","meta-llama/llama-3.3-70b-instruct"],defaultEndpoint:"https://openrouter.ai/api/v1"}};async function L(e,s,r){var d,l,t,n;try{if(e==="gemini"){if(!s)return h.gemini.models;const o=await fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${s}`);if(!o.ok)return h.gemini.models;const c=((await o.json()).models||[]).filter(a=>{var u;return(u=a.supportedGenerationMethods)==null?void 0:u.includes("generateContent")}).map(a=>a.name.replace(/^models\//,"")).filter(a=>!a.includes("embedding")&&!a.includes("aqa")&&!a.includes("text-"));return c.length>0?c:h.gemini.models}if(e==="ollama"){const o=(r||"http://localhost:11434").replace(/\/+$/,""),i=await fetch(`${o}/api/tags`);if(!i.ok)return h.ollama.models;const a=((await i.json()).models||[]).map(u=>u.name);return a.length>0?a:h.ollama.models}if(e==="lmstudio"||e==="openai"||e==="groq"||e==="custom"){let o="",i=s;e==="openai"?o="https://api.openai.com/v1":e==="groq"?o="https://api.groq.com/openai/v1":e==="lmstudio"?(o=(r||"http://localhost:1234/v1").replace(/\/+$/,""),i=s||"lm-studio"):o=(r||"https://openrouter.ai/api/v1").replace(/\/+$/,"");const c=await fetch(`${o}/models`,{headers:i?{Authorization:`Bearer ${i}`}:{}});if(!c.ok)return((d=h[e])==null?void 0:d.models)||[];const u=((await c.json()).data||[]).map(m=>m.id);return u.length>0?u:((l=h[e])==null?void 0:l.models)||[]}}catch{return((t=h[e])==null?void 0:t.models)||[]}return((n=h[e])==null?void 0:n.models)||[]}async function y(e,s,r=!1){const d={...x.value.aiConfig,...s||{}},{provider:l,apiKey:t,model:n,customEndpoint:o,temperature:i}=d;switch(l){case"gemini":return z(e,t,n||"gemini-3.6-flash",i,r);case"openai":return P("https://api.openai.com/v1",e,t,n||"gpt-4o-mini",i,r);case"groq":return P("https://api.groq.com/openai/v1",e,t,n||"llama-3.3-70b-versatile",i,r);case"lmstudio":{const c=(o||"http://localhost:1234/v1").replace(/\/+$/,"");return P(c,e,t||"lm-studio",n||"default",i,r)}case"ollama":return E(o||"http://localhost:11434",e,n||"llama3.2",i,r);case"custom":{const c=(o||"https://openrouter.ai/api/v1").replace(/\/+$/,"");return P(c,e,t,n||"default",i,r)}default:throw new Error(`Unsupported AI Provider: "${l}"`)}}async function z(e,s,r,d=.7,l=!1){var f,w,k,T,v,b,A;if(!s)throw new Error("Google Gemini API Key is missing. Please add it in Extension Settings.");const t=e.find(g=>g.role==="system"),o=e.filter(g=>g.role!=="system").map(g=>({role:g.role==="assistant"?"model":"user",parts:[{text:g.content}]})),i=(r||"gemini-3.6-flash").trim().replace(/^models\//,""),c=`https://generativelanguage.googleapis.com/v1beta/models/${i}:generateContent?key=${s}`,a={contents:o,generationConfig:{temperature:d,...l?{responseMimeType:"application/json"}:{}}};t&&(a.systemInstruction={parts:[{text:t.content}]});const u=await fetch(c,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(a)});if(!u.ok){const g=await u.text();let O=g;try{O=((f=JSON.parse(g).error)==null?void 0:f.message)||g}catch{}throw new Error(`Gemini API Error (${u.status}): ${O}`)}const m=await u.json(),p=(w=m.candidates)==null?void 0:w[0];return{content:((T=(k=p==null?void 0:p.content)==null?void 0:k.parts)==null?void 0:T.map(g=>g.text).join(""))||"",model:i,usage:{promptTokens:(v=m.usageMetadata)==null?void 0:v.promptTokenCount,completionTokens:(b=m.usageMetadata)==null?void 0:b.candidatesTokenCount,totalTokens:(A=m.usageMetadata)==null?void 0:A.totalTokenCount}}}async function P(e,s,r,d,l=.7,t=!1){var p,S,f,w,k,T,v;const n=e.includes("localhost")||e.includes("127.0.0.1");if(!r&&!n)throw new Error("API Key is required for this AI provider. Please configure it in Settings.");const o=`${e.replace(/\/+$/,"")}/chat/completions`,i={"Content-Type":"application/json"};r&&(i.Authorization=`Bearer ${r}`);const c={model:d,messages:s,temperature:l};t&&!n&&(c.response_format={type:"json_object"});const a=await fetch(o,{method:"POST",headers:i,body:JSON.stringify(c)});if(!a.ok){const b=await a.text();let A=b;try{const g=JSON.parse(b);A=((p=g.error)==null?void 0:p.message)||g.message||b}catch{}throw new Error(`AI Provider Error (${a.status}): ${A}`)}const u=await a.json();return{content:((w=(f=(S=u.choices)==null?void 0:S[0])==null?void 0:f.message)==null?void 0:w.content)||"",model:u.model||d,usage:{promptTokens:(k=u.usage)==null?void 0:k.prompt_tokens,completionTokens:(T=u.usage)==null?void 0:T.completion_tokens,totalTokens:(v=u.usage)==null?void 0:v.total_tokens}}}async function E(e,s,r,d=.7,l=!1){var a;const n=`${e.replace(/\/+$/,"")}/api/chat`,o=s.map(u=>({role:u.role,content:u.content})),i=await fetch(n,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:r,messages:o,stream:!1,options:{temperature:d},...l?{format:"json"}:{}})});if(!i.ok){const u=await i.text();throw new Error(`Ollama Error (${i.status}): ${u}`)}const c=await i.json();return{content:((a=c.message)==null?void 0:a.content)||"",model:r,usage:{promptTokens:c.prompt_eval_count,completionTokens:c.eval_count,totalTokens:(c.prompt_eval_count||0)+(c.eval_count||0)}}}async function Y(e){const s=performance.now();try{const r=await y([{role:"system",content:"You are a test assistant. Answer in one short sentence."},{role:"user",content:'Respond with "Connection Successful!" and nothing else.'}],e);return{success:!0,latencyMs:Math.round(performance.now()-s),message:r.content.trim()}}catch(r){return{success:!1,error:r.message||String(r)}}}async function G(e,s){if(e.length===0)return[];const r=e.map((t,n)=>({index:n,url:t.url,title:t.title,channel:t.channelTitle||"Unknown",duration:t.duration||"Unknown",type:t.videoType||"video",existingTags:t.tags||[],descriptionSnippet:(t.description||"").slice(0,300)})),l=await y([{role:"system",content:`You are an expert YouTube cataloging assistant. Analyze the given list of YouTube videos and output accurate, concise categorization tags (3 to 6 tags per video) in lowercase, hyphen-separated format (e.g. "web-development", "react", "tutorial", "machine-learning"). Also suggest an appropriate thematic playlist name for each video.
Respond ONLY with a JSON object containing an array "results", with each item having:
- "index": number (matching input index)
- "url": string
- "tags": string[] (3-6 clean tags)
- "suggestedPlaylist": string (concise playlist name)
- "summary": string (1 brief sentence describing the video)`},{role:"user",content:JSON.stringify(r)}],s,!0);try{const t=JSON.parse(l.content);return(t.results||(Array.isArray(t)?t:[])).map(o=>{var i,c;return{url:o.url||((i=e[o.index])==null?void 0:i.url)||"",videoId:(c=e[o.index])==null?void 0:c.videoId,tags:Array.isArray(o.tags)?o.tags.map(a=>a.toLowerCase().replace(/\s+/g,"-").trim()):[],suggestedPlaylist:o.suggestedPlaylist||"General",summary:o.summary||""}})}catch{throw new Error("Failed to parse AI auto-tagging output as JSON: "+l.content)}}async function U(e,s){const r=`You are a video analyst. Analyze the video metadata and produce:
1. A concise overview (2-3 sentences).
2. 3-5 bulleted key takeaways.
3. 3-5 main topics covered.
4. Target audience level (Beginner, Intermediate, Advanced).
5. 3-5 suggested tags.

Respond ONLY with a JSON object in this format:
{
  "summary": "...",
  "keyTakeaways": ["...", "..."],
  "topics": ["...", "..."],
  "targetAudience": "...",
  "recommendedTags": ["...", "..."]
}`,d=JSON.stringify({title:e.title,channel:e.channelTitle,duration:e.duration,description:e.description||"No description available",type:e.videoType}),l=await y([{role:"system",content:r},{role:"user",content:d}],s,!0);try{const t=JSON.parse(l.content);return{summary:t.summary||"Summary unavailable",keyTakeaways:t.keyTakeaways||[],topics:t.topics||[],targetAudience:t.targetAudience||"General",recommendedTags:t.recommendedTags||[]}}catch{return{summary:l.content,keyTakeaways:[],topics:[],targetAudience:"General",recommendedTags:[]}}}async function j(e,s,r){const d=s.map((n,o)=>({index:o+1,title:n.title,channel:n.channelTitle,duration:n.duration,url:n.url})),l=`You are a learning coordinator. Synthesize the playlist "${e}" containing ${s.length} videos into an educational summary and structured roadmap.
Respond ONLY with a JSON object:
{
  "overview": "A 2-paragraph high level overview of what this playlist teaches",
  "keyThemes": ["theme 1", "theme 2", "theme 3"],
  "recommendedWatchOrder": [
    { "title": "Video title", "url": "Video URL", "rationale": "Why watch this first/next" }
  ],
  "markdownGuide": "# Full Markdown Study Guide\\n..."
}`,t=await y([{role:"system",content:l},{role:"user",content:JSON.stringify({playlistName:e,videos:d})}],r,!0);try{const n=JSON.parse(t.content);return{overview:n.overview||"",recommendedWatchOrder:n.recommendedWatchOrder||[],keyThemes:n.keyThemes||[],markdownGuide:n.markdownGuide||""}}catch{return{overview:t.content,recommendedWatchOrder:[],keyThemes:[],markdownGuide:t.content}}}async function _(e,s,r){const d=s.map(n=>({url:n.url,title:n.title,channel:n.channelTitle,duration:n.duration,tags:n.tags,type:n.videoType,snippet:(n.description||"").slice(0,150)})),t=await y([{role:"system",content:`You are a semantic video search engine. Given the user's natural language query and a list of saved YouTube videos, identify all matching or relevant videos.
Explain why each selected video matches the query.
Respond ONLY with a JSON object:
{
  "matchingUrls": ["url1", "url2"],
  "explanation": "Detailed explanation of findings and answers to the query",
  "suggestedFilter": "Optional suggested tag or keyword"
}`},{role:"user",content:JSON.stringify({userQuery:e,library:d})}],r,!0);try{const n=JSON.parse(t.content);return{matchingUrls:n.matchingUrls||[],explanation:n.explanation||"",suggestedFilter:n.suggestedFilter}}catch{return{matchingUrls:[],explanation:t.content}}}async function M(e,s,r){const d=s.map((n,o)=>({index:o+1,title:n.title,channel:n.channelTitle,duration:n.duration,url:n.url,tags:n.tags,description:(n.description||"").slice(0,400)}));return(await y([{role:"system",content:"You are an AI assistant specialized in analyzing YouTube video collections. The user has provided a custom instruction to run on their selected videos. Formulate a rich, helpful, formatted Markdown response."},{role:"user",content:`User Prompt: ${e}

Selected Videos Context:
${JSON.stringify(d,null,2)}`}],r,!1)).content}async function $(e,s=[],r,d){var c;if(e.length===0)return[];const l=s.filter(a=>a.priority&&a.priority!=="remove").slice(0,15).map(a=>({title:a.title,channel:a.channelTitle||"Unknown",duration:a.duration||"Unknown",priority:a.priority,tags:a.tags||[]})),t=e.map((a,u)=>({index:u,url:a.url,title:a.title,channel:a.channelTitle||"Unknown",duration:a.duration||"Unknown",type:a.videoType||"video",tags:a.tags||[],descriptionSnippet:(a.description||"").slice(0,300),currentPriority:a.priority||"none"})),n=r||((c=x.value.aiConfig)==null?void 0:c.prioritizationDirectives)||"Prioritize actionable, skill-building tutorials and high-impact educational content as Important; breaking news or time-sensitive events as Urgent; leisure or long backlog videos as Delay.",o=`You are an expert personal productivity AI specializing in the Eisenhower Video Prioritization Matrix.
Categorize each YouTube video into one of these 5 quadrants:
1. "urgent": Time-sensitive, fast-decay value, live event, breaking tech announcement, or time-critical tutorial to watch immediately.
2. "important": High long-term value, core tutorials, career development, deep educational content, masterclasses.
3. "delegate": Reference materials, tool recommendations to share with colleagues/friends, or team assets.
4. "delay": Casual entertainment, long leisure podcasts, backlog topics, lower urgency videos to watch someday.
5. "remove": Clickbait, obsolete tech, low quality, redundant duplicates, or videos that should be cleaned up.

User's Learned Habit Examples:
${l.length>0?JSON.stringify(l,null,2):"No prior examples yet. Apply standard productivity heuristics."}

User's Specific Directives & Preferences:
${n}

For each video, output:
- "index": number
- "url": string
- "priority": "urgent" | "important" | "delegate" | "delay" | "remove"
- "confidence": number (0.5 to 1.0)
- "reasoning": 1 concise sentence explaining why this quadrant was chosen based on the title, channel, duration, or topic.
- "suggestedTags": string[] (2-4 relevant tags)

Respond ONLY with a JSON object:
{
  "results": [
    {
      "index": 0,
      "url": "...",
      "priority": "important",
      "confidence": 0.95,
      "reasoning": "Core architectural tutorial from a trusted educator.",
      "suggestedTags": ["react", "architecture"]
    }
  ]
}`,i=await y([{role:"system",content:o},{role:"user",content:JSON.stringify(t)}],d,!0);try{const a=JSON.parse(i.content);return(a.results||(Array.isArray(a)?a:[])).map(m=>{const p=e[m.index]||e.find(w=>w.url===m.url),f=["urgent","important","delegate","delay","remove"].includes(m.priority)?m.priority:"important";return{url:m.url||(p==null?void 0:p.url)||"",videoId:p==null?void 0:p.videoId,title:(p==null?void 0:p.title)||"Unknown Video",priority:f,confidence:typeof m.confidence=="number"?m.confidence:.85,reasoning:m.reasoning||"Categorized by AI based on video metadata.",suggestedTags:Array.isArray(m.suggestedTags)?m.suggestedTags:[]}})}catch{throw new Error("Failed to parse AI prioritization response: "+i.content)}}async function R(e,s){if(e.length===0)throw new Error("Please save some videos to your library first so AI can analyze your habits.");const r=e.slice(0,60).map(t=>({title:t.title,channel:t.channelTitle||"Unknown",duration:t.duration||"Unknown",tags:t.tags||[],priority:t.priority||"unassigned"})),l=await y([{role:"system",content:`You are an AI Workflow & Learning Habits Architect.
Analyze the user's YouTube library habits (channels, topics, video lengths, and any existing priority labels).
Synthesize their implicit prioritization routines and construct a personalized Prioritization Algorithm.

Output format (JSON ONLY):
{
  "userPersonaSummary": "2-3 sentences describing the user's focus (e.g., 'Full-Stack Developer focused on TypeScript & AI, viewing coding masterclasses as high-priority and podcasts during leisure.')",
  "quadrantRules": {
    "urgent": "Clear heuristic for what should be marked Urgent for this user",
    "important": "Clear heuristic for what should be marked Important for this user",
    "delegate": "Clear heuristic for what should be marked Delegate for this user",
    "delay": "Clear heuristic for what should be marked Delay for this user",
    "remove": "Clear heuristic for what should be cleaned up"
  },
  "keyChannelsAndTopics": [
    { "name": "Channel or Topic Name", "priority": "important", "reason": "Why this creator fits this quadrant" }
  ],
  "algorithmicDirectives": "Formatted rule directives that can be used by an automated classifier",
  "recommendedGuidelinesPrompt": "A ready-to-use prompt instruction representing this user's custom prioritization philosophy"
}`},{role:"user",content:`Analyze my YouTube Library and construct my Prioritization Algorithm:
${JSON.stringify(r,null,2)}`}],s,!0);try{const t=JSON.parse(l.content);return{userPersonaSummary:t.userPersonaSummary||"Productivity & Tech Learner",quadrantRules:t.quadrantRules||{urgent:"Time-critical releases and breaking news.",important:"Core skill tutorials, architectural deep-dives, masterclasses.",delegate:"Reference tools and team shareables.",delay:"Long casual podcasts and leisure streams.",remove:"Outdated or clickbait videos."},keyChannelsAndTopics:Array.isArray(t.keyChannelsAndTopics)?t.keyChannelsAndTopics:[],algorithmicDirectives:t.algorithmicDirectives||"",recommendedGuidelinesPrompt:t.recommendedGuidelinesPrompt||""}}catch{throw new Error("Failed to parse AI Routine Profile: "+l.content)}}async function D(e,s){const r=await $([e],[],void 0,s);return r.length>0?{priority:r[0].priority,reasoning:r[0].reasoning,suggestedTags:r[0].suggestedTags||[]}:{priority:"important",reasoning:"Evaluated based on content relevance and channel authority.",suggestedTags:[]}}export{h as A,q as C,$ as a,R as b,G as c,_ as d,j as e,M as f,L as g,D as h,U as i,Y as t};
